package com.ultimatex.nsbm.util;

public interface MainContainerState {

    int SETTINGS = 1;
    int PROFILE = 2;
    int PAYMENT = 3;
    int SCHEDULE = 4;
    int RESULT = 5;
    int SUBJECT = 6;

}
