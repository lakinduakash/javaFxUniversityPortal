package com.ultimatex.nsbm.util;

public class InvalidSessionException extends RuntimeException {

}
