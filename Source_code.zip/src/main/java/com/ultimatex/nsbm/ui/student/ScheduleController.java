package com.ultimatex.nsbm.ui.student;

public class ScheduleController {
}
